#include "project.h"
#include <stdio.h>

uint16_t ConvertToGram(uint16_t adc_count);

#define ADC_COUNT_249G  907 // Målt ADC-værdi ved 750g
#define ADC_COUNT_750G  1840 // Målt ADC-værdi ved 750g
#define GRAM_RANGE      500
#define ADC_RANGE       (ADC_COUNT_750G - ADC_COUNT_249G)

int main(void)
{
    char uartBuffer[256];
    
    UART_1_Start();
    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    
    UART_1_PutString("Scale application started\r\n");

    for(;;)
    {
        if (ADC_SAR_1_IsEndConversion(ADC_SAR_1_WAIT_FOR_RESULT))
        {
            uint16_t result = ADC_SAR_1_GetResult16();
            snprintf(uartBuffer, sizeof(uartBuffer), "ADC Count: %d\r\nWeight: %dg\r\n\r\n", result, ConvertToGram(result));
            UART_1_PutString(uartBuffer);
        }
        CyDelay(1000);
    }
}

uint16_t ConvertToGram(uint16_t adc_count) {
    int32_t diff = (int32_t)adc_count - ADC_COUNT_249G; // Relativ forskel
    int32_t grams = 249 + ((diff * GRAM_RANGE) / ADC_RANGE); // Konvertering til gram
    if (grams < 0) grams = 0; // Clamp til 0, hvis negativ værdi
    return grams;
}